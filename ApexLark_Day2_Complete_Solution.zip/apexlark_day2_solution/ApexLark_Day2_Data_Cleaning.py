# ApexLark AI & Machine Learning Internship — Day 2
# Data Cleaning & Preprocessing Using Python
# Dataset: UCI Wine Quality (red + white wine)

# 1. Import libraries
import os
import zipfile
import urllib.request
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import LabelEncoder

sns.set_theme(style="whitegrid")
pd.set_option("display.max_columns", None)

# 2. Dataset collection
# UCI Machine Learning Repository: Wine Quality dataset
DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)
ZIP_PATH = DATA_DIR / "wine+quality.zip"
URL = "https://archive.ics.uci.edu/static/public/186/wine+quality.zip"

if not ZIP_PATH.exists():
    urllib.request.urlretrieve(URL, ZIP_PATH)

with zipfile.ZipFile(ZIP_PATH, "r") as z:
    z.extractall(DATA_DIR)

red_path = DATA_DIR / "winequality-red.csv"
white_path = DATA_DIR / "winequality-white.csv"

red = pd.read_csv(red_path, sep=";")
white = pd.read_csv(white_path, sep=";")
red["wine_type"] = "red"
white["wine_type"] = "white"

df = pd.concat([red, white], ignore_index=True)
print("Dataset downloaded and combined successfully.")
print("Original shape:", df.shape)
display(df.head())

# 3. Dataset inspection
print("First 10 records")
display(df.head(10))

print("Last 10 records")
display(df.tail(10))

print("Dataset shape:", df.shape)
print("Column names:", df.columns.tolist())
print("\nDataset information:")
df.info()

print("\nSummary statistics:")
display(df.describe(include="all").T)

# 4. Data cleaning
# Missing values
print("Missing values before cleaning:")
display(df.isnull().sum())

# Standardize column names: lowercase and replace spaces with underscores
df.columns = (
    df.columns.str.strip()
              .str.lower()
              .str.replace(" ", "_", regex=False)
)

# Standardize text values
df["wine_type"] = df["wine_type"].astype("string").str.strip().str.lower()

# Remove duplicate rows
duplicates_before = df.duplicated().sum()
df = df.drop_duplicates().copy()
print("Duplicate rows removed:", duplicates_before)

# Correct data types
numeric_cols = [c for c in df.columns if c != "wine_type"]
for col in numeric_cols:
    df[col] = pd.to_numeric(df[col], errors="coerce")

# Handle missing numeric values with median; categorical with mode
for col in df.select_dtypes(include=np.number).columns:
    df[col] = df[col].fillna(df[col].median())

for col in df.select_dtypes(include=["object", "string", "category"]).columns:
    if df[col].isna().any():
        df[col] = df[col].fillna(df[col].mode().iloc[0])

# Remove columns that contain no useful information (none expected here)
constant_cols = [c for c in df.columns if df[c].nunique(dropna=False) <= 1]
if constant_cols:
    df = df.drop(columns=constant_cols)
print("Constant columns removed:", constant_cols)

# 5. Data preprocessing
# Create at least two derived features
df["total_acidity"] = (
    df["fixed_acidity"] + df["volatile_acidity"] + df["citric_acid"]
)
df["alcohol_sugar_ratio"] = df["alcohol"] / (df["residual_sugar"] + 1e-6)

# Convert date columns if any are available
date_cols = [c for c in df.columns if "date" in c.lower()]
for col in date_cols:
    df[col] = pd.to_datetime(df[col], errors="coerce")

# Encode categorical variable using Label Encoding
le = LabelEncoder()
df["wine_type_encoded"] = le.fit_transform(df["wine_type"].astype(str))

# Outlier detection using IQR
outlier_summary = {}
for col in df.select_dtypes(include=np.number).columns:
    q1 = df[col].quantile(0.25)
    q3 = df[col].quantile(0.75)
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    count = ((df[col] < lower) | (df[col] > upper)).sum()
    outlier_summary[col] = {
        "lower_bound": lower,
        "upper_bound": upper,
        "outlier_count": int(count)
    }

outlier_table = pd.DataFrame(outlier_summary).T.sort_values(
    "outlier_count", ascending=False
)
print("IQR outlier summary:")
display(outlier_table)

# Winsorization/capping: cap numeric values at IQR boundaries.
# Do not cap the target quality score or the encoded category.
for col in df.select_dtypes(include=np.number).columns:
    if col in ["quality", "wine_type_encoded"]:
        continue
    q1 = df[col].quantile(0.25)
    q3 = df[col].quantile(0.75)
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    df[col] = df[col].clip(lower, upper)

# 6. Data validation
print("Missing values after preprocessing:", int(df.isna().sum().sum()))
print("Duplicate rows after cleaning:", int(df.duplicated().sum()))
print("Final dataset shape:", df.shape)

categorical_features = df.select_dtypes(include=["object", "string", "category"]).columns.tolist()
numerical_features = df.select_dtypes(include=np.number).columns.tolist()
print("Categorical features:", len(categorical_features), categorical_features)
print("Numerical features:", len(numerical_features), numerical_features)
print("\nUpdated data types:")
display(df.dtypes.to_frame("data_type"))

# Save cleaned data
OUTPUT_DIR = Path("outputs")
OUTPUT_DIR.mkdir(exist_ok=True)
df.to_csv(OUTPUT_DIR / "cleaned_wine_quality.csv", index=False)

# 7. Data visualization
# 7.1 Missing value heatmap (original combined data)
plt.figure(figsize=(12, 5))
sns.heatmap(pd.concat([red, white], ignore_index=True).isna(), cbar=False, yticklabels=False)
plt.title("Missing Value Heatmap — Original Dataset")
plt.xlabel("Columns")
plt.tight_layout()
plt.show()

# 7.2 Box plot for outlier detection
plt.figure(figsize=(12, 6))
sns.boxplot(data=df[["fixed_acidity", "volatile_acidity", "citric_acid",
                     "residual_sugar", "chlorides", "free_sulfur_dioxide",
                     "total_sulfur_dioxide", "density", "pH", "sulphates", "alcohol"]])
plt.title("Box Plot of Numerical Features")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# 7.3 Count plot of categorical feature
plt.figure(figsize=(7, 5))
sns.countplot(data=df, x="wine_type")
plt.title("Count Plot — Wine Type")
plt.xlabel("Wine Type")
plt.ylabel("Number of Records")
plt.tight_layout()
plt.show()

# 7.4 Correlation heatmap
plt.figure(figsize=(12, 9))
sns.heatmap(df.select_dtypes(include=np.number).corr(), annot=False, cmap="coolwarm", center=0)
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.show()

# 7.5 Histogram of a numerical feature
plt.figure(figsize=(8, 5))
sns.histplot(df["alcohol"], bins=30, kde=True)
plt.title("Distribution of Alcohol")
plt.xlabel("Alcohol")
plt.ylabel("Frequency")
plt.tight_layout()
plt.show()

# 8. Business insights (generated from the cleaned dataset)
print("BUSINESS INSIGHTS")
print("1. Total records after cleaning:", len(df))
print("2. Red wine records:", int((df["wine_type"] == "red").sum()))
print("3. White wine records:", int((df["wine_type"] == "white").sum()))
print("4. Average quality score:", round(df["quality"].mean(), 2))
print("5. Average alcohol percentage:", round(df["alcohol"].mean(), 2))

print("\nThree data quality issues checked:")
print("- Missing values were checked and imputed where present.")
print("- Duplicate records were identified and removed.")
print("- Numeric data types and text formatting were standardized.")

print("\nThree preprocessing techniques applied:")
print("- Median/mode imputation for missing values.")
print("- Label encoding for the wine_type category.")
print("- IQR-based outlier detection and capping.")

print("\nThree recommendations before model training:")
print("- Split data into training and testing sets before fitting any model.")
print("- Use a pipeline so imputation, scaling and encoding are fitted on training data only.")
print("- Evaluate class balance and suitable metrics; quality scores may be imbalanced.")

print("\nCleaned dataset saved to outputs/cleaned_wine_quality.csv")
